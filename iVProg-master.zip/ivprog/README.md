# iVProg

Módulo interativo de aprendizagem para o ensino de lógica de programação desenvolvido pelo [LInE](https://www.usp.br/line)
Free Education, Private Data!

# Downloads

As versões estáveis podem ser baixadas através do seguinte [link](http://200.144.254.107/release/ivprog). O projeto usa uma numeração de versão seguindo a formatação: YYYY-MM-DD_HH-MM-SS.


# Desenvolvimento

O projeto utiliza o npm como gerenciador de pacotes e ferramenta de construção. Para montar o programa a partir do código fonte é necessário ter instalado o Java (para o analisador léxico baseado em antlr4) e nodejs(^10.16.0) com npm(^6.9.0).
Após clone este repositório execute os seguintes comandos a partir da pasta raiz:

```
npm install
npm run build
npm run start
```

Após a execução desses comandos, você poderá acessar o localhost na porta 8080 para acessar a sua versão local do iVProg.
Existem também o comando _npm run watch_ para compilar os arquivos enquanto você faz modificações no código

If you have Apache, go to the source code run "npm run build" and copy the content of directory "build/" to your "localhost/ivprog/".

import { Literal } from './literal';
import { Types } from './../../typeSystem/types';

export class CharLiteral extends Literal {
  
  constructor(value) {
    super(Types.CHAR);
    this.value = value;
  }

  toString () {
    const text = `'${this.value}'`;
    if(this.parenthesis) {
      return `(${text})`
    } else {
      return text;
    }
  }
}
import { Literal } from './literal';
import { Types } from './../../typeSystem/types';

export class VariableLiteral extends Literal {
  
  constructor(id) {
    super(Types.UNDEFINED);
    this.id = id;
  }

  toString () {
    if(this.parenthesis) {
      return `(${this.id})`;
    } else {
      return this.id;
    }
  }
}
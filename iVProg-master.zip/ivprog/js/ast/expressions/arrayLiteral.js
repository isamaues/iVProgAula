import { Literal } from './literal';

export class ArrayLiteral extends Literal {
  
  /**
   * 
   * @param {import('../../typeSystem/itype').IType} type 
   * @param {import('./expression').Expression[]} value 
   */
  constructor(type, value) {
    super(type);
    this.value = value;
  }

  get subtype () {
    const element = this.value[0];
    if (element instanceof ArrayLiteral) {
      return element.value[0].type;
    } else {
      return element.type;
    }
  }

  get lines () {
    return this.value.length;
  }

  get columns () {
    const element = this.value[0];
    if (!(element instanceof ArrayLiteral)){
      return null;
    } else {
      return element.value.length;
    }
  }

  get isVector () {
    return this.columns === null;
  }

  get isValid () {
    return this.validateSize() && this.validateType();
  }

  validateType () {
    const valid = true;
    // const subtype = this.subtype;
    // if(this.columns !== null) {
    //   const len = this.lines;
    //   const len2 = this.columns;
    //   for (let i = len - 1; i >= 0 && valid; --i) {
    //     for (let j = len2 - 1; j >= 0 && valid; --j) {
    //       if(!this.value[i].value[j].type.isCompatilbe(subtype)) {
    //         valid = false;
    //         break;
    //       }
    //     }
    //   }
    // } else {
    //   const len = this.lines;
    //   for (var i = len - 1; i >= 0 && valid; i--) {
    //     if(!this.value[i].type.isCompatilbe(subtype)) {
    //       valid = false;
    //       break;
    //     }
    //   }
    // }
    // Cannot validate type since no information on variables literals are available
    return valid;
  }

  validateSize () {
    const valid = true;
    // if(this.columns !== null) {
    //   const equalityTest = this.value.map(v => v.value.length)
    //     .reduce((old, next) => {
    //       console.log(next);
    //       if (old == null) {
    //         return next;
    //       } else if (old === next) {
    //         return old
    //       } else {
    //         return -1;
    //       }
    //     }, null);
    //   valid = equalityTest !== -1;
    // }
    // check is now made inside IVProgParser.parseVectorList(...)
    return valid;
  }

  toString () {
    const strList = this.value.map(arrayLiteral => arrayLiteral.toString());
    const text = "{" + strList.join(',') + "}";
    if(this.parenthesis) {
      return `(${text})`;
    } else {
      return text;
    }
  }
}

import {InfixApp} from './infixApp';

export class UnaryApp extends InfixApp {
  
  constructor (op, left) {
    super(op, left, null);
  }

  toString () {
    const l = this.left.toString();
    const op = this.op.value;
    if(this.parenthesis) {
      return `(${op + l})`;
    } else {
      return op + l;
    }
  }
}
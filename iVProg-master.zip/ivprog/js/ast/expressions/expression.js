export class Expression {

  constructor () {
		this._sourceInfo = null;
		this._parenthesis = false;
  }

  set sourceInfo (sourceInfo) {
		this._sourceInfo = sourceInfo;
	}

	get sourceInfo () {
		return this._sourceInfo;
	}

	set parenthesis (flag) {
		this._parenthesis = flag;
	}

	get parenthesis () {
		return this._parenthesis;
	}
}
import * as LocalizedStringsService from "./../../services/localizedStringsService";
import { SyntaxError } from "./syntaxError";

const LocalizedStrings = LocalizedStringsService.getInstance();

function createError (message_id, context = []) {
  return new SyntaxError(
    LocalizedStrings.getError(message_id, context),
    message_id
  );
}

export const SyntaxErrorFactory = Object.freeze({
  extra_lines: () => new SyntaxError(LocalizedStrings.getError("extra_lines")),
  token_missing_one: (expected, token) => {
    const context = [expected, token.text, token.line, token.col];
    const error = createError("token_missing_one", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  token_missing_list: (expectedList, token) => {
    const line = expectedList.join(LocalizedStrings.getOR());
    const error = SyntaxErrorFactory.token_missing_one(line, token);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  id_missing: (token) => {
    const context = [token.text, token.line, token.col];
    const error = createError("id_missing", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  eos_missing: (token) => {
    const context = [token.line, token.col];
    const error = createError("eos_missing", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  invalid_array_dimension: (typeName, token) => {
    const context = [token.line, token.col, typeName];
    const error = createError("invalid_array_dimension", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  invalid_array_size: (token) => {
    const context = [token.line];
    const error = createError("invalid_array_size", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  invalid_main_return: (name, typeName, token) => {
    const context = [name, typeName, token.line];
    const error = createError("invalid_main_return", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  invalid_var_declaration: (token) => {
    const context = [token.line];
    const error = createError("invalid_var_declaration", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  invalid_break_command: (cmdName, token) => {
    const context = [token.line, cmdName];
    const error = createError("invalid_break_command", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  invalid_terminal: (token) => {
    const context = [token.text, token.line, token.col];
    const error = createError("invalid_terminal", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  invalid_type: (list, token) => {
    const line = list.join(LocalizedStrings.getOR());
    const context = [token.text, token.line, token.col, line];
    const error = createError("invalid_type", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  const_not_init: (token) => {
    const context = [token.line, token.col];
    const error = createError("const_not_init", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  invalid_id_format: (token) => {
    const context = [token.text, token.line, token.col];
    const error = createError("invalid_id_format", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  duplicate_function: (token) => {
    const context = [token.text, token.line, token.col];
    const error = createError("duplicate_function", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  main_parameters: () => {
    return createError("main_parameters");
  },
  duplicate_variable: (token) => {
    const context = [token.text, token.line, token.col];
    const error = createError("duplicate_variable", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  invalid_character: (text, line, column) => {
    const context = [text, line];
    const error = createError("invalid_character", context);
    error.context = { line: line, column: column };
    return error;
  },
  annonymous_array_literal: (token) => {
    const context = [token.line];
    const error = createError("annonymous_array_literal", context);
    error.context = { line: token.line, column: token.col};
    return error;
  },
  invalid_matrix_literal_line: (exp, sourceInfo) => {
    const context = [exp, sourceInfo.line];
    const error = createError("invalid_matrix_literal_line", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  cannot_infer_matrix_line: (name, sourceInfo) => {
    const context = [name, sourceInfo.line];
    const error = createError("cannot_infer_matrix_line", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  cannot_infer_matrix_column: (name, sourceInfo) => {
    const context = [name, sourceInfo.line];
    const error = createError("cannot_infer_matrix_column", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  cannot_infer_vector_size: (name, sourceInfo) => {
    const context = [name, sourceInfo.line];
    const error = createError("cannot_infer_vector_size", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  matrix_to_vector_literal_attr: (name, exp, sourceInfo) => {
    const context = [sourceInfo.line, exp, name];
    const error = createError("matrix_to_vector_literal_attr", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  vector_to_matrix_literal_attr: (name, exp, sourceInfo) => {
    const context = [sourceInfo.line, exp, name];
    const error = createError("vector_to_matrix_literal_attr", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  array_init_not_literal: (sourceInfo) => {
    const context = [sourceInfo.line];
    const error = createError("array_init_not_literal", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  array_exceeds_2d: (sourceInfo) => {
    const context = [sourceInfo.line];
    const error = createError("array_exceeds_2d", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  invalid_matrix_id_dimension: (sourceInfo) => {
    const context = [sourceInfo.line];
    const error = createError("invalid_matrix_id_dimension", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  invalid_vector_init: (sourceInfo) => {
    const context = [sourceInfo.line];
    const error = createError("invalid_vector_init", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  invalid_matrix_init: (sourceInfo) => {
    const context = [sourceInfo.line];
    const error = createError("invalid_matrix_init", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  invalid_syntax: (text, line, column) => {
    const context = [text, line];
    const error = createError("invalid_syntax", context);
    error.context = { line: line, column: column };
    return error;
  }
});

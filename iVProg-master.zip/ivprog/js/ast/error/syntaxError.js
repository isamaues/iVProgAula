export class SyntaxError extends Error {
  constructor (msg, id) {
    super(msg);
    this.id = id;
    this._context = {};
    if (Error.captureStackTrace) Error.captureStackTrace(this, SyntaxError);
  }

  get context () {
    return this._context;
  }

  set context (contextObj) {
    this._context = contextObj;
  }
}

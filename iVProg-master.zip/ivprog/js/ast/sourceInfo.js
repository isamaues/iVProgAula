export class SourceInfo {

  /**
    * @param {moo.Token} token
    *
    * @return {SourceInfo}
    * **/
  static createSourceInfo (token) {
    return new SourceInfo(token.line, token.col, token.text, token.text.length);
  }

  /**
    * @param {moo.Token} tokenA
    * @param {moo.Token} tokenB
    *
    * @return {SourceInfo}
    * **/
  static createSourceInfoFromList (tokenA, tokenB) {
    const line = tokenA.line;
    const column = tokenA.col;
    // adapted from https://github.com/UNIVALI-LITE/Portugol-Studio/blob/master/core/src/main/java/br/univali/portugol/nucleo/analise/sintatica/Portugol.g
    // No idea why...
    const size = tokenB.offset + 1 - tokenA.offset
    return new SourceInfo(line, column, "", size);
  }

  /**
   * @param {number} line
   * @param {number} column
   * @param {string} text
   * @param {number} size
    * **/
  constructor (line, column, text, size) {
    this.line = line;
    this.column = column;
    this.text = text;
    this.size = size;
  }

}

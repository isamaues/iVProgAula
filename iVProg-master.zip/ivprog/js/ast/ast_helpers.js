import { SyntaxErrorFactory } from "./error/syntaxErrorFactory";

export function recover (_) {
    const start = this._tokenStartCharIndex;
    const stop = this._input.index;
    let text = this._input.getText(start, stop);
    text = this.getErrorDisplay(text);
    const line = this._tokenStartLine;
    const column = this._tokenStartColumn;
    throw SyntaxErrorFactory.invalid_character(text, line, column);
}

export class FormalParameter {

  constructor (type, id, byRef = false, variadic = false) {
    this.type = type;
    this.id = id;
    this.byRef = byRef;
    this.variadic = variadic;
    this._sourceInfo = null;
  }

  set sourceInfo (sourceInfo) {
		this._sourceInfo = sourceInfo;
	}

	get sourceInfo () {
		return this._sourceInfo;
	}
}
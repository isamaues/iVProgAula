import { Command } from './command';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { Expression } from '../expressions/expression';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { Case } from '.';

export class Switch extends Command {
  
  /**
   * 
   * @param {Expression} expression 
   * @param {Case[]} cases 
   */
  constructor (expression, cases) {
    super();
    this.expression = expression;
    this.cases = cases;
  }
}
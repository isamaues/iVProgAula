import { Command } from './command';

export class For extends Command {

  constructor (for_id, for_from, for_to, for_pass, commandBlock) {
    super();
    this.for_id = for_id;
    this.for_from = for_from;
    this.for_to = for_to;
    this.for_pass = for_pass;
    this.commandBlock = commandBlock;
  }

  get commands () {
    return this.commandBlock.commands;
  }
}
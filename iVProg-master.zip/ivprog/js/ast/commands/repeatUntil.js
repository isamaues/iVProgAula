import { While } from './while';

export class RepeatUntil extends While {

  constructor(condition, commandBlock) {
    super(condition, commandBlock);
  }

  get testFirst () {
    return false;
  }
  
}
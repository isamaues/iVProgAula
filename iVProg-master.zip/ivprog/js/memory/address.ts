export class Address {

  public id: number;
  public value: unknown;

  /**
   * 
   * @param {Number} id the address id
   * @param {never} value the value stored at this address
   */
  constructor (id: number, value: unknown) {
    this.id = id;
    this.value = value;
  }
}
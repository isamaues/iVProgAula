export const Types = Object.freeze({
  INTEGER: "integer",
  REAL: "real",
  TEXT: "text",
  CHAR: 'char',
  BOOLEAN: "boolean",
  VOID: "void"
});
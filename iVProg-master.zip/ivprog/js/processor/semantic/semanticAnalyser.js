import { ProcessorErrorFactory } from "./../error/processorErrorFactory";
import { LanguageDefinedFunction } from "./../definedFunctions";
import {
  ArrayDeclaration,
  While,
  For,
  Switch,
  Assign,
  Break,
  IfThenElse,
  Return,
  ArrayIndexAssign,
} from "../../ast/commands";
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { Expression } from "./../../ast/expressions/expression";
import {
  InfixApp,
  UnaryApp,
  FunctionCall,
  IntLiteral,
  RealLiteral,
  StringLiteral,
  BoolLiteral,
  VariableLiteral,
  ArrayAccess,
  CharLiteral,
} from "../../ast/expressions";
import { Literal } from "../../ast/expressions/literal";
import {
  resultTypeAfterInfixOp,
  resultTypeAfterUnaryOp,
} from "../compatibilityTable";
import { Types } from "../../typeSystem/types";
import { ArrayType } from "../../typeSystem/array_type";
import { MultiType } from "../../typeSystem/multiType";
import { Config } from "../../util/config";
import { Store } from "../store/store";
import { IVProgParser } from "../../ast/ivprogParser";

export class SemanticAnalyser {
  static analyseFromSource (stringCode) {
    const parser = IVProgParser.createParser(stringCode);
    const semantic = new SemanticAnalyser(parser.parseTree());
    return semantic.analyseTree();
  }

  constructor (ast) {
    this.ast = ast;
    this.symbolMap = null;
    this.currentFunction = null;
  }

  pushMap () {
    if (this.symbolMap === null) {
      this.symbolMap = { map: {}, next: null };
    } else {
      const n = { map: {}, next: this.symbolMap };
      this.symbolMap = n;
    }
  }

  popMap () {
    if (this.symbolMap !== null) {
      this.symbolMap = this.symbolMap.next;
    }
  }

  insertSymbol (id, typeInfo) {
    this.symbolMap.map[id] = typeInfo;
  }

  findSymbol (id, symbol_map) {
    if (!symbol_map.map[id]) {
      if (symbol_map.next) {
        return this.findSymbol(id, symbol_map.next);
      }
      return null;
    } else {
      return symbol_map.map[id];
    }
  }

  getMainFunction () {
    return this.ast.functions.find((v) => v.isMain);
  }

  findFunction (name) {
    if (name.match(/^\$.+$/)) {
      const fun = LanguageDefinedFunction.getFunction(name);
      if (!fun) {
        throw ProcessorErrorFactory.not_implemented(name);
      }
      return fun;
    } else {
      const val = this.ast.functions.find((v) => v.name === name);
      if (!val) {
        return null;
      }
      return val;
    }
  }

  analyseTree () {
    const globalVars = this.ast.global;
    this.pushMap();
    this.assertDeclarations(globalVars);
    const functions = this.ast.functions;
    const mainFunc = functions.filter((f) => f.name === null);
    if (mainFunc.length <= 0) {
      throw ProcessorErrorFactory.main_missing();
    }
    for (let i = 0; i < functions.length; i++) {
      const fun = functions[i];
      this.assertFunction(fun);
    }
    return this.ast;
  }

  assertDeclarations (list) {
    for (let i = 0; i < list.length; i++) {
      this.assertDeclaration(list[i]);
    }
  }

  assertDeclaration (declaration) {
    if (declaration instanceof ArrayDeclaration) {
      this.assertArrayDeclaration(declaration);
      this.insertSymbol(declaration.id, {
        id: declaration.id,
        lines: declaration.lines,
        columns: declaration.columns,
        type: declaration.type,
        isConst: declaration.isConst,
      });
    } else {
      if (declaration.initial === null) {
        this.insertSymbol(declaration.id, {
          id: declaration.id,
          type: declaration.type,
          isConst: declaration.isConst,
        });
        return;
      }
      const resultType = this.evaluateExpressionType(declaration.initial);
      if (resultType instanceof MultiType) {
        if (!resultType.isCompatible(declaration.type)) {
          const stringInfo = declaration.type.stringInfo();
          const info = stringInfo[0];
          const result_string_info = resultType.stringInfo();
          const result_info = result_string_info[0];
          const exp = declaration.initial;
          throw ProcessorErrorFactory.incompatible_types_full(
            info.type,
            info.dim,
            result_info.type,
            result_info.dim,
            exp.toString(),
            declaration.sourceInfo
          );
        }
        this.insertSymbol(declaration.id, {
          id: declaration.id,
          type: declaration.type,
          isConst: declaration.isConst,
        });
      } else if (
        (!declaration.type.isCompatible(resultType) &&
          !Config.enable_type_casting) ||
        (!declaration.type.isCompatible(resultType) &&
          Config.enable_type_casting &&
          !Store.canImplicitTypeCast(declaration.type, resultType))
      ) {
        const stringInfo = declaration.type.stringInfo();
        const info = stringInfo[0];
        const result_string_info = resultType.stringInfo();
        const result_info = result_string_info[0];
        const exp = declaration.initial;
        throw ProcessorErrorFactory.incompatible_types_full(
          info.type,
          info.dim,
          result_info.type,
          result_info.dim,
          exp.toString(),
          declaration.sourceInfo
        );
      } else {
        this.insertSymbol(declaration.id, {
          id: declaration.id,
          type: declaration.type,
          isConst: declaration.isConst,
        });
      }
    }
  }

  assertArrayDeclaration (declaration) {
    if (declaration.initial === null) {
      const lineType = this.evaluateExpressionType(declaration.lines);
      if (!lineType.isCompatible(Types.INTEGER)) {
        throw ProcessorErrorFactory.array_dimension_not_int_full(
          declaration.sourceInfo
        );
      }
      if (declaration.columns !== null) {
        const columnType = this.evaluateExpressionType(declaration.columns);
        if (!columnType.isCompatible(Types.INTEGER)) {
          throw ProcessorErrorFactory.array_dimension_not_int_full(
            declaration.sourceInfo
          );
        }
      }
    } else {
      this.evaluateArrayLiteral(declaration);
    }
    this.insertSymbol(declaration.id, {
      id: declaration.id,
      lines: declaration.lines,
      columns: declaration.columns,
      type: declaration.type,
    });
    return;
  }

  evaluateExpressionType (expression) {
    // TODO: Throw operator error in case type == UNDEFINED
    if (expression instanceof UnaryApp) {
      const op = expression.op;
      const resultType = this.evaluateExpressionType(expression.left);
      const finalResult = resultTypeAfterUnaryOp(op, resultType);
      if (Types.UNDEFINED.isCompatible(finalResult)) {
        const stringInfo = resultType.stringInfo();
        const info = stringInfo[0];
        const expString = expression.toString();
        throw ProcessorErrorFactory.invalid_unary_op_full(
          expString,
          op,
          info.type,
          info.dim,
          expression.sourceInfo
        );
      }
      return finalResult;
    } else if (expression instanceof InfixApp) {
      const op = expression.op;
      const resultTypeLeft = this.evaluateExpressionType(expression.left);
      const resultTypeRight = this.evaluateExpressionType(expression.right);
      const finalResult = resultTypeAfterInfixOp(
        op,
        resultTypeLeft,
        resultTypeRight
      );
      if (Types.UNDEFINED.isCompatible(finalResult)) {
        const stringInfoLeft = resultTypeLeft.stringInfo();
        const infoLeft = stringInfoLeft[0];
        const stringInfoRight = resultTypeRight.stringInfo();
        const infoRight = stringInfoRight[0];
        const expString = expression.toString();
        throw ProcessorErrorFactory.invalid_infix_op_full(
          expString,
          op,
          infoLeft.type,
          infoLeft.dim,
          infoRight.type,
          infoRight.dim,
          expression.sourceInfo
        );
      }
      return finalResult;
    } else if (expression instanceof Literal) {
      return this.evaluateLiteralType(expression);
    } else if (expression instanceof FunctionCall) {
      if (expression.isMainCall) {
        throw ProcessorErrorFactory.void_in_expression_full(
          LanguageDefinedFunction.getMainFunctionName(),
          expression.sourceInfo
        );
      }
      const fun = this.findFunction(expression.id);
      if (fun === null) {
        throw ProcessorErrorFactory.function_missing_full(
          expression.id,
          expression.sourceInfo
        );
      }
      if (fun.returnType.isCompatible(Types.VOID)) {
        throw ProcessorErrorFactory.void_in_expression_full(
          expression.id,
          expression.sourceInfo
        );
      }
      this.assertParameters(fun, expression.actualParameters);
      return fun.returnType;
    } else if (expression instanceof ArrayAccess) {
      const arrayTypeInfo = this.findSymbol(expression.id, this.symbolMap);
      if (arrayTypeInfo === null) {
        throw ProcessorErrorFactory.symbol_not_found_full(
          expression.id,
          expression.sourceInfo
        );
      }
      if (!(arrayTypeInfo.type instanceof ArrayType)) {
        throw ProcessorErrorFactory.invalid_array_access_full(
          expression.id,
          expression.sourceInfo
        );
      }
      const lineType = this.evaluateExpressionType(expression.line);
      if (!lineType.isCompatible(Types.INTEGER)) {
        throw ProcessorErrorFactory.array_dimension_not_int_full(
          expression.sourceInfo
        );
      }
      if (expression.column !== null) {
        if (arrayTypeInfo.columns === null) {
          throw ProcessorErrorFactory.invalid_matrix_access_full(
            expression.id,
            expression.sourceInfo
          );
        }
        const columnType = this.evaluateExpressionType(expression.column);
        if (!columnType.isCompatible(Types.INTEGER)) {
          throw ProcessorErrorFactory.array_dimension_not_int_full(
            expression.sourceInfo
          );
        }
      }
      const arrType = arrayTypeInfo.type;
      if (expression.column !== null) {
        // indexing matrix
        return arrType.innerType;
      } else {
        if (arrayTypeInfo.columns === null) {
          return arrType.innerType;
        }
        return new ArrayType(arrType.innerType, 1);
      }
    }
  }

  evaluateLiteralType (literal) {
    if (literal instanceof IntLiteral) {
      return literal.type;
    } else if (literal instanceof RealLiteral) {
      return literal.type;
    } else if (literal instanceof StringLiteral) {
      return literal.type;
    } else if (literal instanceof BoolLiteral) {
      return literal.type;
    } else if (literal instanceof CharLiteral) {
      return literal.type;
    } else if (literal instanceof VariableLiteral) {
      const typeInfo = this.findSymbol(literal.id, this.symbolMap);
      if (typeInfo === null) {
        throw ProcessorErrorFactory.symbol_not_found_full(
          literal.id,
          literal.sourceInfo
        );
      }
      if (typeInfo.type instanceof ArrayType) {
        return typeInfo.type;
      }
      return typeInfo.type;
    } else {
      // console.warn("Evaluating type only for an array literal...");
      let last = null;
      if (literal.value.length === 1) {
        last = this.evaluateExpressionType(literal.value[0]);
      } else {
        for (let i = 0; i < literal.value.length; i++) {
          const e = this.evaluateExpressionType(literal.value[i]);
          if (last === null) {
            last = e;
          } else if (!last.isCompatible(e)) {
            const strInfo = last.stringInfo();
            const info = strInfo[0];
            const strExp = literal.toString();
            throw ProcessorErrorFactory.incompatible_types_array_full(
              strExp,
              info.type,
              info.dim,
              literal.sourceInfo
            );
          }
        }
      }
      if (last instanceof ArrayType) {
        return new ArrayType(last.innerType, last.dimensions + 1);
      }
      return new ArrayType(last, 1);
    }
  }

  evaluateArrayLiteral (arrayDeclaration) {
    const type = arrayDeclaration.type;
    const literal = arrayDeclaration.initial;
    // console.log(arrayDeclaration);
    if (arrayDeclaration.isVector) {
      this.evaluateVectorLiteralType(literal, type);
    } else {
      // TODO matrix type check
      for (let i = 0; i < literal.lines; ++i) {
        const line_literal = literal.value[i];
        this.evaluateVectorLiteralType(
          line_literal,
          new ArrayType(type.innerType, 1)
        );
      }
    }
    return true;
  }

  assertFunction (fun) {
    this.pushMap();
    this.currentFunction = fun;
    fun.formalParameters.forEach((formalParam) => {
      if (formalParam.type instanceof ArrayType) {
        if (formalParam.type.dimensions > 1) {
          this.insertSymbol(formalParam.id, {
            id: formalParam.id,
            lines: -1,
            columns: -1,
            type: formalParam.type,
          });
        } else {
          this.insertSymbol(formalParam.id, {
            id: formalParam.id,
            lines: -1,
            columns: null,
            type: formalParam.type,
          });
        }
      } else {
        this.insertSymbol(formalParam.id, {
          id: formalParam.id,
          type: formalParam.type,
        });
      }
    });
    this.assertDeclarations(fun.variablesDeclarations);
    const optional = fun.returnType.isCompatible(Types.VOID);
    const valid = this.assertReturn(fun, optional);
    if (!valid) {
      throw ProcessorErrorFactory.function_no_return(fun.name);
    }
    this.popMap();
  }

  assertReturn (fun, optional) {
    return fun.commands.reduce(
      (last, next) => this.checkCommand(fun.returnType, next, optional) || last,
      optional
    );
  }

  checkCommand (type, cmd, optional) {
    if (cmd instanceof While) {
      const resultType = this.evaluateExpressionType(cmd.expression);
      if (!resultType.isCompatible(Types.BOOLEAN)) {
        throw ProcessorErrorFactory.loop_condition_type_full(
          cmd.expression.toString(),
          cmd.sourceInfo
        );
      }
      this.checkCommands(type, cmd.commands, optional);
      return false;
    } else if (cmd instanceof For) {
      const var_type = this.evaluateExpressionType(cmd.for_id);
      if (!var_type.isCompatible(Types.INTEGER)) {
        throw ProcessorErrorFactory.invalid_for_variable(
          cmd.for_id,
          cmd.sourceInfo
        );
      }
      const from_type = this.evaluateExpressionType(cmd.for_from);
      if (!from_type.isCompatible(Types.INTEGER)) {
        throw ProcessorErrorFactory.invalid_for_from(
          cmd.for_from,
          cmd.sourceInfo
        );
      }
      const to_type = this.evaluateExpressionType(cmd.for_to);
      if (!to_type.isCompatible(Types.INTEGER)) {
        throw ProcessorErrorFactory.invalid_for_to(cmd.for_to, cmd.sourceInfo);
      }
      if (cmd.for_pass != null) {
        const pass_type = this.evaluateExpressionType(cmd.for_pass);
        if (!pass_type.isCompatible(Types.INTEGER)) {
          throw ProcessorErrorFactory.invalid_for_pass(
            cmd.for_pass,
            cmd.sourceInfo
          );
        }
      }
      this.checkCommands(type, cmd.commands, optional);
      return false;
    } else if (cmd instanceof Switch) {
      const sType = this.evaluateExpressionType(cmd.expression);
      let result = optional;
      let hasDefault = false;
      for (let i = 0; i < cmd.cases.length; i++) {
        const aCase = cmd.cases[i];
        if (aCase.expression !== null) {
          const caseType = this.evaluateExpressionType(aCase.expression);
          if (!sType.isCompatible(caseType)) {
            const strInfo = sType.stringInfo();
            const info = strInfo[0];
            const strExp = aCase.expression.toString();
            throw ProcessorErrorFactory.invalid_case_type_full(
              strExp,
              info.type,
              info.dim,
              aCase.sourceInfo
            );
          }
        } else {
          hasDefault = true;
        }
        result = result && this.checkCommands(type, aCase.commands, result);
      }
      return result && hasDefault;
    } else if (cmd instanceof ArrayIndexAssign) {
      // TODO - rework!!!!!
      let used_dims = 0;
      const typeInfo = this.findSymbol(cmd.id, this.symbolMap);
      if (typeInfo === null) {
        throw ProcessorErrorFactory.symbol_not_found_full(
          cmd.id,
          cmd.sourceInfo
        );
      }
      if (typeInfo.isConst) {
        throw ProcessorErrorFactory.invalid_const_assignment_full(
          cmd.id,
          cmd.sourceInfo
        );
      }
      if (!(typeInfo.type instanceof ArrayType)) {
        throw ProcessorErrorFactory.invalid_array_access_full(
          cmd.id,
          cmd.sourceInfo
        );
      }
      const exp = cmd.expression;
      const lineExp = cmd.line;
      const lineType = this.evaluateExpressionType(lineExp);
      if (!lineType.isCompatible(Types.INTEGER)) {
        throw ProcessorErrorFactory.array_dimension_not_int_full(
          cmd.sourceInfo
        );
      }
      used_dims += 1;
      const columnExp = cmd.column;
      if (typeInfo.columns === null && columnExp !== null) {
        throw ProcessorErrorFactory.invalid_matrix_access_full(
          cmd.id,
          cmd.sourceInfo
        );
      } else if (columnExp !== null) {
        const columnType = this.evaluateExpressionType(columnExp);
        if (!columnType.isCompatible(Types.INTEGER)) {
          throw ProcessorErrorFactory.array_dimension_not_int_full(
            cmd.sourceInfo
          );
        }
        used_dims += 1;
      }
      // exp a single value exp or an array access
      const exp_type = this.evaluateExpressionType(exp);
      const access_type = typeInfo.type;

      let compatible = false;
      let type = access_type;
      if (exp_type instanceof MultiType) {
        if (access_type.dimensions - used_dims == 0) {
          type = access_type.innerType;
        } else {
          type = new ArrayType(
            access_type.innerType,
            Math.max(0, access_type.dimensions - used_dims)
          );
        }
        compatible = exp_type.isCompatible(type);
      } else {
        compatible = access_type.canAccept(exp_type, used_dims);
      }
      if (!compatible) {
        if (0 === access_type.dimensions - used_dims) {
          type = access_type.innerType; // enable a valid attempt to cast real <--> integer
        }
        if (
          !Config.enable_type_casting ||
          !Store.canImplicitTypeCast(type, exp_type)
        ) {
          const access_type_string_info = access_type.stringInfo();
          const access_type_info = access_type_string_info[0];
          const exp_type_string_info = exp_type.stringInfo();
          const exp_type_info = exp_type_string_info[0];
          throw ProcessorErrorFactory.incompatible_types_full(
            access_type_info.type,
            access_type_info.dim - used_dims,
            exp_type_info.type,
            exp_type_info.dim,
            exp.toString(),
            cmd.sourceInfo
          );
        }
      }
      return optional;
    } else if (cmd instanceof Assign) {
      // TODO - rework since there is no literal array assignment
      const typeInfo = this.findSymbol(cmd.id, this.symbolMap);
      if (typeInfo === null) {
        throw ProcessorErrorFactory.symbol_not_found_full(
          cmd.id,
          cmd.sourceInfo
        );
      }
      if (typeInfo.isConst) {
        throw ProcessorErrorFactory.invalid_const_assignment_full(
          cmd.id,
          cmd.sourceInfo
        );
      }
      const exp = cmd.expression;
      const exp_type = this.evaluateExpressionType(exp);
      if (exp_type instanceof ArrayType) {
        if (!(typeInfo.type instanceof ArrayType)) {
          // TODO better error message
          throw new Error("Cannot assign an array to a non-array variable ");
        }
        // Both are arrays...
        // if both don't have same dimensions and type, cannot perform assignment
        if (!exp_type.isCompatible(typeInfo.type)) {
          if (
            exp_type.dimensions === typeInfo.type.dimensions &&
            !exp_type.innerType.isCompatible(typeInfo.type.innerType)
          ) {
            if (
              !Config.enable_type_casting ||
              !Store.canImplicitTypeCast(
                typeInfo.type.innerType,
                exp_type.innerType
              )
            ) {
              const stringInfo = typeInfo.type.stringInfo();
              const info = stringInfo[0];
              const exp_type_string_info = exp_type.stringInfo();
              const exp_type_info = exp_type_string_info[0];
              throw ProcessorErrorFactory.incompatible_types_full(
                info.type,
                info.dim,
                exp_type_info.type,
                exp_type_info.dim,
                exp.toString(),
                cmd.sourceInfo
              );
            }
          } else {
            switch (exp_type.dimensions) {
              case 1: {
                throw ProcessorErrorFactory.vector_to_matrix_attr(
                  cmd.id,
                  exp.toString(),
                  cmd.sourceInfo
                );
              }
              case 2: {
                throw ProcessorErrorFactory.matrix_to_vector_attr(
                  cmd.id,
                  exp.toString(),
                  cmd.sourceInfo
                );
              }
            }
          }
        }
      } else if (!exp_type.isCompatible(typeInfo.type)) {
        if (
          !Config.enable_type_casting ||
          !Store.canImplicitTypeCast(typeInfo.type, exp_type)
        ) {
          const stringInfo = typeInfo.type.stringInfo();
          const info = stringInfo[0];
          const exp_type_string_info = exp_type.stringInfo();
          const exp_type_info = exp_type_string_info[0];
          throw ProcessorErrorFactory.incompatible_types_full(
            info.type,
            info.dim,
            exp_type_info.type,
            exp_type_info.dim,
            exp.toString(),
            cmd.sourceInfo
          );
        }
      }
      return optional;
    } else if (cmd instanceof Break) {
      return optional;
    } else if (cmd instanceof IfThenElse) {
      const resultType = this.evaluateExpressionType(cmd.condition);
      if (!resultType.isCompatible(Types.BOOLEAN)) {
        throw ProcessorErrorFactory.if_condition_type_full(
          cmd.condition.toString(),
          cmd.sourceInfo
        );
      }
      if (cmd.ifFalse instanceof IfThenElse) {
        return (
          this.checkCommands(type, cmd.ifTrue.commands, optional) &&
          this.checkCommand(type, cmd.ifFalse, optional)
        );
      } else if (cmd.ifFalse != null) {
        return (
          this.checkCommands(type, cmd.ifTrue.commands, optional) &&
          this.checkCommands(type, cmd.ifFalse.commands, optional)
        );
      } else {
        return this.checkCommands(type, cmd.ifTrue.commands, optional);
      }
    } else if (cmd instanceof FunctionCall) {
      let fun = null;
      if (cmd.isMainCall) {
        fun = this.getMainFunction();
      } else {
        fun = this.findFunction(cmd.id);
      }
      if (fun === null) {
        throw ProcessorErrorFactory.function_missing_full(
          cmd.id,
          cmd.sourceInfo
        );
      }
      this.assertParameters(fun, cmd.actualParameters);
      return optional;
    } else if (cmd instanceof Return) {
      const funcName = this.currentFunction.isMain
        ? LanguageDefinedFunction.getMainFunctionName()
        : this.currentFunction.name;
      if (cmd.expression === null && !type.isCompatible(Types.VOID)) {
        const stringInfo = type.stringInfo();
        const info = stringInfo[0];
        throw ProcessorErrorFactory.invalid_void_return_full(
          funcName,
          info.type,
          info.dim,
          cmd.sourceInfo
        );
      } else if (cmd.expression !== null) {
        const resultType = this.evaluateExpressionType(cmd.expression);
        if (!type.isCompatible(resultType)) {
          if (
            !Config.enable_type_casting ||
            !Store.canImplicitTypeCast(type, resultType)
          ) {
            const stringInfo = type.stringInfo();
            const info = stringInfo[0];
            throw ProcessorErrorFactory.invalid_return_type_full(
              funcName,
              info.type,
              info.dim,
              cmd.sourceInfo
            );
          }
        }
        return true;
      } else {
        return true;
      }
    }
  }

  checkCommands (type, cmds, optional) {
    return cmds.reduce(
      (last, next) => this.checkCommand(type, next, optional) || last,
      optional
    );
  }

  /**
   *
   * @param {import('./../../ast/commands/function').Function} fun
   * @param {Expression[]} actualParametersList
   */
  assertParameters (fun, actualParametersList) {
    const parameterList = fun.formalParameters;
    if (
      parameterList.length > actualParametersList.length ||
      (parameterList.length !== actualParametersList.length &&
        !fun.hasVariadic())
    ) {
      throw ProcessorErrorFactory.invalid_parameters_size_full(
        fun.name,
        actualParametersList.length,
        fun.formalParameters.length,
        null
      );
    }

    for (
      let i = 0, j = 0;
      i < parameterList.length && j < actualParametersList.length;
      i += 1, j += 1
    ) {
      const formalParam = parameterList[i];
      if (formalParam.variadic && i + 1 !== parameterList.length) {
        throw "A function variadic parameter must be its last parameter!";
      }
      if (formalParam.variadic) {
        j = this.assertVariadicParameter(
          fun,
          formalParam,
          j,
          actualParametersList
        );
      } else {
        const param = actualParametersList[j];
        this.assertParameter(fun, formalParam, param);
      }
    }
  }

  evaluateVectorLiteralType (literal, type) {
    // console.log(literal);
    for (let i = 0; i < literal.value.length; i += 1) {
      const exp = literal.value[i];
      const expType = this.evaluateExpressionType(exp);
      let compatible = false;
      if (expType instanceof MultiType) {
        compatible = expType.isCompatible(type.innerType);
      } else {
        compatible = type.canAccept(expType, 1);
      }
      if (!compatible) {
        if (
          !Config.enable_type_casting ||
          !Store.canImplicitTypeCast(type.innerType, expType)
        ) {
          const stringInfo = type.stringInfo();
          const info = stringInfo[0];
          const result_string_info = expType.stringInfo();
          const result_info = result_string_info[0];
          throw ProcessorErrorFactory.incompatible_types_full(
            info.type,
            0,
            result_info.type,
            result_info.dim,
            exp.toString(),
            literal.sourceInfo
          );
        }
      }
    }
    return type;
  }

  /**
   *
   * @param {import('./../../ast/commands/function').Function} fun
   * @param {import('./../../ast/commands/formalParameter').FormalParameter} formalParam
   * @param {number} index
   * @param {Expression[]} actualParametersList
   */
  assertVariadicParameter (fun, formalParam, index, actualParametersList) {
    let i;
    for (i = index; i < actualParametersList.length; i += 1) {
      this.assertParameter(fun, formalParam, actualParametersList[i]);
    }
    return i - 1;
  }

  /**
   *
   * @param {import('./../../ast/commands/function').Function} fun
   * @param {import('./../../ast/commands/formalParameter').FormalParameter} formalParam
   * @param {Expression} actualParameter
   */
  assertParameter (fun, formalParam, actualParameter) {
    // const id = formalParam.id;
    if (formalParam.byRef) {
      if (actualParameter instanceof VariableLiteral) {
        const variable = this.findSymbol(actualParameter.id, this.symbolMap);
        if (variable.isConst) {
          throw ProcessorErrorFactory.invalid_const_ref_full(
            fun.name,
            actualParameter.toString(),
            actualParameter.sourceInfo
          );
        }
      } else if (
        !(
          actualParameter instanceof VariableLiteral ||
          actualParameter instanceof ArrayAccess
        )
      ) {
        throw ProcessorErrorFactory.invalid_parameter_type_full(
          fun.name,
          actualParameter.toString(),
          actualParameter.sourceInfo
        );
      }
    }
    const resultType = this.evaluateExpressionType(actualParameter);
    if (
      resultType instanceof MultiType &&
      formalParam.type instanceof MultiType
    ) {
      let shared = 0;
      for (let j = 0; j < resultType.types.length; ++j) {
        const element = resultType.types[j];
        if (formalParam.type.types.indexOf(element) !== -1) {
          shared += 1;
        }
      }
      if (shared <= 0) {
        if (Config.enable_type_casting && !formalParam.byRef) {
          if (
            (!resultType.isCompatible(Types.INTEGER) &&
              !resultType.isCompatible(Types.REAL)) ||
            formalParam.type.isCompatible(Types.INTEGER) ||
            formalParam.type.isCompatible(Types.REAL)
          ) {
            throw ProcessorErrorFactory.invalid_parameter_type_full(
              fun.name,
              actualParameter.toString(),
              actualParameter.sourceInfo
            );
          }
        }
      }
    } else if (resultType instanceof MultiType) {
      if (!resultType.isCompatible(formalParam.type)) {
        if (Config.enable_type_casting && !formalParam.byRef) {
          if (
            (!resultType.isCompatible(Types.INTEGER) &&
              !resultType.isCompatible(Types.REAL)) ||
            formalParam.type.isCompatible(Types.INTEGER) ||
            formalParam.type.isCompatible(Types.REAL)
          ) {
            throw ProcessorErrorFactory.invalid_parameter_type_full(
              fun.name,
              actualParameter.toString(),
              actualParameter.sourceInfo
            );
          }
        }
      }
    } else if (!formalParam.type.isCompatible(resultType)) {
      if (Config.enable_type_casting && !formalParam.byRef) {
        if (!Store.canImplicitTypeCast(formalParam.type, resultType)) {
          throw ProcessorErrorFactory.invalid_parameter_type_full(
            fun.name,
            actualParameter.toString(),
            actualParameter.sourceInfo
          );
        }
      }
    }
  }
}

import { IType } from "../../../typeSystem/itype";

export interface IStoreValue {
  type: IType;
  get () : any;
  id? : String;
  isConst: boolean;
  inStore: () => boolean;
}
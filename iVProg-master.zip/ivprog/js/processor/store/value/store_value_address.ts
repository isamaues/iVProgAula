import { StoreValue } from "./store_value";
import { IType } from "../../../typeSystem/itype";

export class StoreValueAddress extends StoreValue {

  constructor (type: IType, value: any, public line: number, public column?: number, id?:String, isConst = false)  {
    super(type,value,id, isConst);
  }
}
import { IStoreValue } from "./istore_value";
import { StoreValueAddress } from "./store_value_address";
import { ArrayType } from "../../../typeSystem/array_type";

export class ArrayStoreValueRef implements IStoreValue {

  public isConst = false;

  constructor(public type: ArrayType, private values: StoreValueAddress[],
    private addresses: number[], public lines: number, public columns:number,
    public id:String) { }

  get () {
    return this.values;
  }

  getAddresses (): number[] {
    return this.addresses;
  }

  inStore () {
    return this.id != null;
  }
}
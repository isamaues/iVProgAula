import { IStoreValue } from "./istore_value";
import { IType } from "../../../typeSystem/itype";

export class StoreValue implements IStoreValue {
  
  public type: IType;
  public id?: String;
  public isConst: boolean;
  public value: any;

  constructor(type: IType, value: any, id?:String, isConst = false) {
    this.type = type;
    this.id = id;
    this.isConst = isConst
    this.value = value;
  }

  get (): any {
    return this.value;
  }

  inStore () {
    return this.id != null;
  }

}
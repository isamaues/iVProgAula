import { IStoreValue } from "./istore_value";
import { Type } from "../../../typeSystem/type";

export class StoreValueRef implements IStoreValue {

  public isConst = false;
  private reference_dimesion = 0;

  constructor(public type: Type, public value: any, private loc_address: number, public id:String) {

  }

  get () {
    return this.value;
  }

  getRefAddress () : number {
    return this.loc_address;
  }

  inStore () {
    return this.id != null;
  }

  getReferenceDimension (): number {
    return this.reference_dimesion;
  }

  setReferenceDimension (dimension: number):void {
    this.reference_dimesion = dimension;
  }
}
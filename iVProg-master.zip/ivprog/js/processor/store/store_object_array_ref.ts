import { StoreObjectArray } from "./storeObjectArray";
import { ArrayStoreValueRef } from "./value/array_store_value_ref";

export class StoreObjectArrayRef extends StoreObjectArray {

  private refObj: String;

  constructor(stoValue: ArrayStoreValueRef, lines:number, columns:number) {
    super(stoValue.type, lines, columns, stoValue.getAddresses(), false);
    this.refObj = stoValue.id;
  }

  get isRef () {
    return true;
  }

  getRefObj (): String {
    return this.refObj;
  }

  destroy () {
    return false;
  }
}
import { StoreObject } from './storeObject';
import { StoreValueRef } from './value/store_value_ref';

export class StoreObjectRef extends StoreObject {

  private refObj: String;
  private reference_dimension: number;

  /**
   * 
   * @param {StoreObject} stoValue 
   */
  constructor (stoValue: StoreValueRef) {
    super(stoValue.type, stoValue.getRefAddress(), false);
    this.refObj = stoValue.id!;
    this.reference_dimension = stoValue.getReferenceDimension();
  }

  get isRef () {
    return true;
  }

  getRefObj (): String {
    return this.refObj;
  }

  getReferenceDimension (): number {
    return this.reference_dimension;
  }

  destroy () {
    return false;
  }
}
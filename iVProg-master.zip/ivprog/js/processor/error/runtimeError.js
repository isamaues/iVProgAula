export class RuntimeError extends Error {
  constructor (msg, id) {
    super(msg);
    this.id = id;
    this._context = {};
    if (Error.captureStackTrace) Error.captureStackTrace(this, RuntimeError);
  }

  get context () {
    return this._context;
  }

  set context (contextObj) {
    this._context = contextObj;
  }
}

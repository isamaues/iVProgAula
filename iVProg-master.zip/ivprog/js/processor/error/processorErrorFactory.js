import { RuntimeError } from "./runtimeError";
import { SemanticError } from "./semanticError";
import * as LocalizedStringsService from "./../../services/localizedStringsService";
import { LanguageDefinedFunction } from "../definedFunctions";

function createRuntimeError (i18n_id, context = []) {
  const LocalizedStrings = LocalizedStringsService.getInstance();
  return new RuntimeError(LocalizedStrings.getError(i18n_id, context), i18n_id);
}

function createSemanticError (i18n_id, context = []) {
  const LocalizedStrings = LocalizedStringsService.getInstance();
  return new SemanticError(
    LocalizedStrings.getError(i18n_id, context),
    i18n_id
  );
}

export const ProcessorErrorFactory = Object.freeze({
  symbol_not_found_full: (id, sourceInfo) => {
    if (sourceInfo) {
      const context = [id, sourceInfo.line, sourceInfo.column];
      const error = createSemanticError("symbol_not_found_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.symbol_not_found(id);
    }
  },
  symbol_not_found: (id) => {
    const context = [id];
    return createSemanticError("symbol_not_found", context);
  },
  function_missing_full: (id, sourceInfo) => {
    if (sourceInfo) {
      const context = [id, sourceInfo.line, sourceInfo.column];
      const error = createSemanticError("function_missing_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.function_missing(id);
    }
  },
  function_missing: (id) => {
    const context = [id];
    return createSemanticError("function_missing", context);
  },
  main_missing: () => {
    return createSemanticError("main_missing");
  },
  array_dimension_not_int_full: (sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line];
      const error = createSemanticError(
        "array_dimension_not_int_full",
        context
      );
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.array_dimension_not_int();
    }
  },
  array_dimension_not_int: () => {
    return createSemanticError("array_dimension_not_int");
  },
  unknown_command_full: (sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line];
      const error = createRuntimeError("unknown_command_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.unknown_command();
    }
  },
  unknown_command: () => {
    return createRuntimeError("unknown_command");
  },
  incompatible_types_full: (
    left_type,
    left_dim,
    right_type,
    right_dim,
    exp,
    source_info
  ) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    if (source_info) {
      const context = [
        LocalizedStrings.translateType(left_type, left_dim),
        exp,
        source_info.line,
        LocalizedStrings.translateType(right_type, right_dim),
      ];
      const error = createSemanticError("incompatible_types_full", context);
      error.context = { line: source_info.line, column: source_info.column };
      return error;
    } else {
      return ProcessorErrorFactory.incompatible_types(
        left_type,
        left_dim,
        right_type,
        right_dim,
        exp
      );
    }
  },
  incompatible_types: (left_type, left_dim, right_type, right_dim, exp) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    const context = [
      LocalizedStrings.translateType(left_type, left_dim),
      exp,
      LocalizedStrings.translateType(right_type, right_dim),
    ];
    return createSemanticError("incompatible_types", context);
  },
  incompatible_types_array_full: (exp, type, dim, sourceInfo) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    if (sourceInfo) {
      const context = [
        exp,
        LocalizedStrings.translateType(type, dim),
        sourceInfo.line,
        sourceInfo.column,
      ];
      const error = createSemanticError(
        "incompatible_types_array_full",
        context
      );
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.incompatible_types_array(exp, type, dim);
    }
  },
  incompatible_types_array: (exp, type, dim) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    const context = [exp, LocalizedStrings.translateType(type, dim)];
    return createSemanticError("incompatible_types_array", context);
  },
  loop_condition_type_full: (exp, sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line, sourceInfo.column, exp];
      const error = createSemanticError("loop_condition_type_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.loop_condition_type(exp);
    }
  },
  loop_condition_type: (exp) => {
    const context = [exp];
    return createSemanticError("loop_condition_type", context);
  },
  /**
   * @deprecated 01/10/2019
   */
  endless_loop_full: (sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line];
      const error = createSemanticError("endless_loop_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.endless_loop();
    }
  },
  endless_loop: () => {
    return createSemanticError("endless_loop");
  },
  if_condition_type_full: (exp, sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line, sourceInfo.column, exp];
      const error = createSemanticError("if_condition_type_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.if_condition_type(exp);
    }
  },
  if_condition_type: (exp) => {
    const context = [exp];
    return createSemanticError("if_condition_type", context);
  },
  invalid_global_var: () => {
    return createRuntimeError("invalid_global_var");
  },
  not_implemented: (id) => {
    const context = [id];
    return createRuntimeError("not_implemented", context);
  },
  invalid_case_type_full: (exp, type, dim, sourceInfo) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    if (sourceInfo) {
      const context = [
        exp,
        LocalizedStrings.translateType(type, dim),
        sourceInfo.line,
        sourceInfo.column,
      ];
      const error = createSemanticError("invalid_case_type_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_case_type(exp, type, dim);
    }
  },
  invalid_case_type: (exp, type, dim) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    const context = [exp, LocalizedStrings.translateType(type, dim)];
    return createSemanticError("invalid_case_type", context);
  },
  void_in_expression_full: (id, sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line, sourceInfo.column, id];
      const error = createSemanticError("void_in_expression_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.void_in_expression(id);
    }
  },
  void_in_expression: (id) => {
    const context = [id];
    return createSemanticError("void_in_expression", context);
  },
  invalid_array_access_full: (id, sourceInfo) => {
    if (sourceInfo) {
      const context = [id, sourceInfo.line, sourceInfo.column];
      const error = createSemanticError("invalid_array_access_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_array_access(id);
    }
  },
  invalid_array_access: (id) => {
    const context = [id];
    return createSemanticError("invalid_array_access", context);
  },
  invalid_matrix_access_full: (id, sourceInfo) => {
    if (sourceInfo) {
      const context = [id, sourceInfo.line, sourceInfo.column];
      const error = createSemanticError("invalid_matrix_access_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_matrix_access(id);
    }
  },
  invalid_matrix_access: (id) => {
    const context = [id];
    return createSemanticError("invalid_matrix_access", context);
  },
  matrix_column_outbounds_full: (id, value, columns, sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line, value, id, columns];
      const error = createRuntimeError("matrix_column_outbounds_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.matrix_column_outbounds(id, value, columns);
    }
  },
  matrix_column_outbounds: (id, value, columns) => {
    const context = [value, id, columns];
    return createRuntimeError("matrix_column_outbounds", context);
  },
  matrix_line_outbounds_full: (id, value, lines, sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line, value, id, lines];
      const error = createRuntimeError("matrix_line_outbounds_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.matrix_line_outbounds(id, value, lines);
    }
  },
  matrix_line_outbounds: (id, value, lines) => {
    const context = [value, id, lines];
    return createRuntimeError("matrix_line_outbounds", context);
  },
  vector_line_outbounds_full: (id, value, lines, sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line, value, id, lines];
      const error = createRuntimeError("vector_line_outbounds_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.vector_line_outbounds(id, value, lines);
    }
  },
  vector_line_outbounds: (id, value, lines) => {
    const context = [value, id, lines];
    return createRuntimeError("vector_line_outbounds", context);
  },
  vector_not_matrix_full: (id, sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line, id];
      const error = createRuntimeError("vector_not_matrix_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.vector_not_matrix(id);
    }
  },
  vector_not_matrix: (id) => {
    const context = [id];
    return createRuntimeError("vector_not_matrix", context);
  },
  function_no_return: (id) => {
    const context = [id];
    return createSemanticError("function_no_return", context);
  },
  invalid_void_return_full: (id, type, dim, sourceInfo) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    if (sourceInfo) {
      const context = [
        sourceInfo.line,
        id,
        LocalizedStrings.translateType(type, dim),
      ];
      const error = createSemanticError("invalid_void_return_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_void_return(id, type, dim);
    }
  },
  invalid_void_return: (id, type, dim) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    const context = [id, LocalizedStrings.translateType(type, dim)];
    return createSemanticError("invalid_void_return_full", context);
  },
  invalid_return_type_full: (id, type, dim, sourceInfo) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();

    if (sourceInfo) {
      const context = [
        sourceInfo.line,
        id,
        LocalizedStrings.translateType(type, dim),
      ];
      const error = createSemanticError("invalid_return_type_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_return_type(id, type, dim);
    }
  },
  invalid_return_type: (id, type, dim) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    const context = [id, LocalizedStrings.translateType(type, dim)];
    return createSemanticError("invalid_return_type", context);
  },
  invalid_parameters_size_full: (id, expected, actual, sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line, id, expected, actual];
      const error = createSemanticError(
        "invalid_parameters_size_full",
        context
      );
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_parameters_size(
        id,
        expected,
        actual
      );
    }
  },
  invalid_parameters_size: (id, expected, actual) => {
    const context = [id, expected, actual];
    return createSemanticError("invalid_parameters_size", context);
  },
  invalid_parameter_type_full: (fun_name, exp, sourceInfo) => {
    if (sourceInfo) {
      const context = [
        exp,
        LanguageDefinedFunction.getLocalName(fun_name),
        sourceInfo.line,
      ];
      const error = createSemanticError("invalid_parameter_type_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_parameter_type(fun_name, exp);
    }
  },
  invalid_parameter_type: (fun_name, exp) => {
    const context = [exp, LanguageDefinedFunction.getLocalName(fun_name)];
    return createSemanticError("invalid_parameter_type_full", context);
  },
  invalid_ref_full: (id, exp, sourceInfo) => {
    if (sourceInfo) {
      const context = [exp, id, sourceInfo.line];
      const error = createSemanticError("invalid_ref_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_ref(id, exp);
    }
  },
  invalid_ref: (id, exp) => {
    const context = [exp, id];
    return createSemanticError("invalid_ref", context);
  },
  unexpected_break_command_full: (sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line];
      const error = createRuntimeError(
        "unexpected_break_command_full",
        context
      );
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.unexpected_break_command();
    }
  },
  unexpected_break_command: () => {
    return createRuntimeError("unexpected_break_command");
  },
  invalid_array_literal_type_full: (exp, sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line, exp];
      const error = createRuntimeError(
        "invalid_array_literal_type_full",
        context
      );
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_array_literal_type(exp);
    }
  },
  invalid_array_literal_type: (exp) => {
    const context = [exp];
    return createRuntimeError("invalid_array_literal_type", context);
  },
  invalid_array_literal_line_full: (expected, actual, sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line, expected, actual];
      const error = createRuntimeError(
        "invalid_array_literal_line_full",
        context
      );
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_array_literal_type(expected, actual);
    }
  },
  invalid_array_literal_line: (expected, actual) => {
    const context = [expected, actual];
    return createRuntimeError("invalid_array_literal_line", context);
  },
  invalid_array_literal_column_full: (expected, actual, sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line, expected, actual];
      const error = createRuntimeError(
        "invalid_array_literal_column_full",
        context
      );
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_array_literal_column(
        expected,
        actual
      );
    }
  },
  invalid_array_literal_column: (expected, actual) => {
    const context = [expected, actual];
    return createRuntimeError("invalid_array_literal_column", context);
  },
  invalid_unary_op_full: (expString, opName, type, dim, sourceInfo) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    if (sourceInfo) {
      const context = [
        sourceInfo.line,
        expString,
        LocalizedStrings.translateOp(opName),
        LocalizedStrings.translateType(type, dim),
      ];
      const error = createRuntimeError("invalid_unary_op_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_unary_op(opName, type, dim);
    }
  },
  invalid_unary_op: (expString, opName, type, dim) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    const context = [
      expString,
      LocalizedStrings.translateOp(opName),
      LocalizedStrings.translateType(type, dim),
    ];
    return createRuntimeError("invalid_unary_op", context);
  },
  invalid_infix_op_full: (
    expString,
    opName,
    typeLeft,
    dimLeft,
    typeRight,
    dimRight,
    sourceInfo
  ) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    if (sourceInfo) {
      const context = [
        sourceInfo.line,
        expString,
        LocalizedStrings.translateOp(opName),
        LocalizedStrings.translateType(typeLeft, dimLeft),
        LocalizedStrings.translateType(typeRight, dimRight),
      ];
      const error = createRuntimeError("invalid_infix_op_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_infix_op(
        opName,
        typeLeft,
        dimLeft,
        typeRight,
        dimRight
      );
    }
  },
  invalid_infix_op: (
    expString,
    opName,
    typeLeft,
    dimLeft,
    typeRight,
    dimRight
  ) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    const context = [
      expString,
      LocalizedStrings.translateOp(opName),
      LocalizedStrings.translateType(typeLeft, dimLeft),
      LocalizedStrings.translateType(typeRight, dimRight),
    ];
    return createRuntimeError("invalid_infix_op", context);
  },
  array_dimension_not_positive_full: (sourceInfo) => {
    if (sourceInfo) {
      const context = [sourceInfo.line];
      const error = createSemanticError(
        "array_dimension_not_positive_full",
        context
      );
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.array_dimension_not_positive();
    }
  },
  array_dimension_not_positive: () => {
    return createSemanticError("array_dimension_not_positive");
  },
  invalid_type_conversion: (value, type, dim) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();

    const context = [value, LocalizedStrings.translateType(type, dim)];
    return createRuntimeError("invalid_type_conversion", context);
  },
  invalid_read_type: (exp, type, dim, name, source_info) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    const context = [
      source_info.line,
      exp,
      LocalizedStrings.translateType(type, dim),
      name,
    ];
    const error = createRuntimeError("invalid_read_type", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  invalid_read_type_array: (
    exp,
    typePos,
    dimPos,
    name,
    typeArray,
    dimArray,
    sourceInfo
  ) => {
    const LocalizedStrings = LocalizedStringsService.getInstance();
    const context = [
      sourceInfo.line,
      exp,
      LocalizedStrings.translateType(typePos, dimPos),
      name,
      LocalizedStrings.translateType(typeArray, dimArray),
    ];
    const error = createRuntimeError("invalid_read_type_array", context);
    error.context = { line: sourceInfo.line, column: sourceInfo.column };
    return error;
  },
  invalid_const_ref_full: (fun_name, exp, sourceInfo) => {
    if (sourceInfo) {
      const context = [
        exp,
        LanguageDefinedFunction.getLocalName(fun_name),
        sourceInfo.line,
      ];
      const error = createSemanticError("invalid_const_ref_full", context);
      error.context = { line: sourceInfo.line, column: sourceInfo.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_const_ref(fun_name, exp);
    }
  },
  invalid_const_ref: (fun_name, exp) => {
    const context = [exp, LanguageDefinedFunction.getLocalName(fun_name)];
    const error = createSemanticError("invalid_const_ref", context);
    return error;
  },
  invalid_const_assignment_full: (var_id, source_info) => {
    if (source_info) {
      const context = [source_info.line, var_id];
      const error = createSemanticError(
        "invalid_const_assignment_full",
        context
      );
      error.context = { line: source_info.line, column: source_info.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_const_assignment(var_id);
    }
  },
  invalid_const_assignment: (var_id) => {
    const context = [var_id];
    return createSemanticError("invalid_const_assignment", context);
  },
  invalid_vector_assignment_full: (
    left_id,
    left_size,
    right_id,
    right_size,
    source_info
  ) => {
    if (source_info) {
      const context = [
        source_info.line,
        left_id,
        left_size,
        right_id,
        right_size,
      ];
      const error = createRuntimeError(
        "invalid_vector_assignment_full",
        context
      );
      error.context = { line: source_info.line, column: source_info.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_vector_assignment(
        left_id,
        left_size,
        right_id,
        right_size
      );
    }
  },
  invalid_vector_assignment: (left_id, left_size, right_id, right_size) => {
    const context = [left_id, left_size, right_id, right_size];
    return createRuntimeError("invalid_vector_assignment", context);
  },
  invalid_matrix_assignment_full: (
    left_id,
    left_line,
    left_column,
    right_id,
    right_line,
    right_column,
    source_info
  ) => {
    if (source_info) {
      const context = [
        source_info.line,
        left_id,
        left_line,
        left_column,
        right_id,
        right_line,
        right_column,
      ];
      const error = createRuntimeError(
        "invalid_matrix_assignment_full",
        context
      );
      error.context = { line: source_info.line, column: source_info.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_matrix_assignment(
        left_id,
        left_line,
        left_column,
        right_id,
        right_line,
        right_column
      );
    }
  },
  invalid_matrix_assignment: (
    left_id,
    left_line,
    left_column,
    right_id,
    right_line,
    right_column
  ) => {
    const context = [
      left_id,
      left_line,
      left_column,
      right_id,
      right_line,
      right_column,
    ];
    return createRuntimeError("invalid_matrix_assignment", context);
  },
  matrix_to_vector_attr: (left_id, right_id, source_info) => {
    // SourceInfo have to be valid...
    const context = [source_info.line, right_id, left_id];
    const error = createSemanticError("matrix_to_vector_attr", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  vector_to_matrix_attr: (left_id, right_id, source_info) => {
    // SourceInfo have to be valid...
    const context = [source_info.line, right_id, left_id];
    const error = createSemanticError("vector_to_matrix_attr", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  invalid_matrix_index_assign_full: (
    mat_id,
    mat_line,
    mat_size,
    exp,
    exp_size,
    source_info
  ) => {
    if (source_info) {
      const context = [
        source_info.line,
        mat_line,
        mat_id,
        mat_size,
        exp,
        exp_size,
      ];
      const error = createRuntimeError(
        "invalid_matrix_index_assign_full",
        context
      );
      error.context = { line: source_info.line, column: source_info.column };
      return error;
    } else {
      return ProcessorErrorFactory.invalid_matrix_index_assign(
        mat_id,
        mat_line,
        mat_size,
        exp,
        exp_size
      );
    }
  },
  invalid_matrix_index_assign: (mat_id, mat_line, mat_size, exp, exp_size) => {
    const context = [mat_line, mat_id, mat_size, exp, exp_size];
    return createRuntimeError("invalid_matrix_index_assign", context);
  },
  invalid_number_elements_vector: (
    expected_num,
    exp,
    actual_num,
    source_info
  ) => {
    // SourceInfo have to be valid...
    const context = [expected_num, source_info.line, exp, actual_num];
    const error = createRuntimeError("invalid_number_elements_vector", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  invalid_number_lines_matrix: (expected_num, exp, actual_num, source_info) => {
    // SourceInfo have to be valid...
    const context = [expected_num, source_info.line, exp, actual_num];
    const error = createRuntimeError("invalid_number_lines_matrix", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  divsion_by_zero_full: (exp, source_info) => {
    if (source_info) {
      const context = [source_info.line, exp];
      const error = createRuntimeError("divsion_by_zero_full", context);
      error.context = { line: source_info.line, column: source_info.column };
      return error;
    } else {
      return ProcessorErrorFactory.divsion_by_zero(exp);
    }
  },
  divsion_by_zero: (exp) => {
    const context = [exp];
    return createRuntimeError("divsion_by_zero", context);
  },
  undefined_tanget_value: (value, source_info) => {
    const context = [source_info.line, value];
    const error = createRuntimeError("undefined_tanget_value", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  negative_log_value: (source_info) => {
    const error = createRuntimeError("negative_log_value", [source_info.line]);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  invalid_string_index: (index, str, source_info) => {
    const local_fun_name = LanguageDefinedFunction.getLocalName("$charAt");
    const context = [
      source_info.line,
      local_fun_name,
      index,
      str,
      str.length - 1,
    ];
    const error = createRuntimeError("invalid_string_index", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  negative_sqrt_value: (source_info) => {
    const error = createRuntimeError("negative_sqrt_value", [source_info.line]);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  /**
   * @deprecated 01/10/2019
   */
  exceeded_recursive_calls: (source_info) => {
    const context = [source_info.line];
    const error = createRuntimeError("exceeded_recursive_calls", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  invalid_for_variable: (id, source_info) => {
    const context = [source_info.line, id];
    const error = createSemanticError("invalid_for_variable", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  invalid_for_from: (exp, source_info) => {
    const context = [source_info.line, exp];
    const error = createSemanticError("invalid_for_from", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  invalid_for_to: (exp, source_info) => {
    const context = [source_info.line, exp];
    const error = createSemanticError("invalid_for_to", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  invalid_for_pass: (exp, source_info) => {
    const context = [source_info.line, exp];
    const error = createSemanticError("invalid_for_pass", context);
    error.context = { line: source_info.line, column: source_info.column };
    return error;
  },
  exceed_max_instructions: () => {
    return createRuntimeError("exceed_max_instructions");
  },
});


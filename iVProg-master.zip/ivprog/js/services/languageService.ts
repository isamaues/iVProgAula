declare const iLMparameters: any; // Tell Typescript iLMparameters is a global

import Lexers from "./../../grammar/";
import line_i18n from "line-i18n";
import { Config } from "./../util/config";
import {
  IVProgLexer,
  I18N_LANG_FUNCS,
  I18N_LANG_LIBS,
} from "../../grammar/lexer";

class LanguageServiceExtended extends line_i18n.LanguageServiceNoLS {
  constructor () {
    super(
      typeof iLMparameters === "undefined"
        ? Config.default_lang
        : iLMparameters.lang
    );
  }

  getDefaultLang (): string {
    return "en";
  }

  getCurrentLexer (): IVProgLexer {
    const langLexer = Lexers[this.getLang()];
    if (langLexer === null || langLexer === undefined) {
      return Lexers[this.getDefaultLang()];
    } else {
      return langLexer;
    }
  }

  getCurrentLangFuncs (): I18N_LANG_FUNCS {
    const langInfo = Lexers[this.getLang()];
    if (langInfo === null || langInfo === undefined) {
      return Lexers[this.getDefaultLang()].getLangFuncs();
    } else {
      return langInfo.getLangFuncs();
    }
  }

  getCurrentLangLibs (): I18N_LANG_LIBS {
    const langInfo = Lexers[this.getLang()];
    if (langInfo === null || langInfo === undefined) {
      return Lexers[this.getDefaultLang()].getLangLibs();
    }
    return langInfo.getLangLibs();
  }
}

export const LanguageService = new LanguageServiceExtended();

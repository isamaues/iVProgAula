import line_i18n from 'line-i18n'
import { IVProgProcessor } from "./../processor/ivprogProcessor";
import { DOMConsole} from "./../io/domConsole";
import * as LocalizedStringsService from "../services/localizedStringsService";
import { OutputMatching } from './output_matching/output_matching';
import { Config } from '../util/config';


const LocalizedStrings = LocalizedStringsService.getInstance();

const StringTypes = line_i18n.StringTypes;

const AssessmentConfig = {
  max_instruction_count: 350250,
  suspend_threshold: 200
}

export class IVProgAssessment {

  constructor (ast_code, testCases, domConsole) {
    this.ast_code = ast_code;
    this.testCases = testCases;
    this.domConsole = domConsole;
    this.old_config = JSON.parse(JSON.stringify(Config));
    Config.setConfig(AssessmentConfig);
  }

  runTest () {
    try {
      // loop test cases and show messages through domconsole
      const partialTests = this.testCases.map( (t, name) => {
        return new OutputMatching(new IVProgProcessor(this.ast_code), t.input, t.output, name);
      });
      const testResult = partialTests.map(om => om.eval());
      return Promise.all(testResult).then(results => {
        let grade = 0;
        for(let i = 0; i < results.length; i += 1) {
          const result = results[i];
          grade += result.grade;
          if(result.grade == 1) {
            this.writeToConsole(DOMConsole.INFO, StringTypes.MESSAGE,'test_case_success',
              result.name + 1, result.generateOutput());
          } else if (result.status == 1) {
            this.writeToConsole(DOMConsole.ERR, StringTypes.ERROR,'test_case_failed_exception',
              result.name + 1, result.error_msg, result.generateOutput());
          } else {
            this.writeToConsole(DOMConsole.ERR, StringTypes.ERROR,'test_case_failed',
              result.name + 1, result.generateOutput());
          }
        }
        grade /= results.length;
        const channel = grade == 1 ? DOMConsole.INFO : DOMConsole.ERR;
        this.writeToConsole(channel, StringTypes.MESSAGE, "test_suite_grade", (grade * 100).toFixed(2));
        return grade;
      });
      // return testResult.then(function (total) {
      //   const grade = total / this.testCases.length;
      //   const channel = grade == 1 ? DOMConsole.INFO : DOMConsole.ERR;
      //   this.writeToConsole(channel, StringTypes.MESSAGE, "test_suite_grade", (grade * 100).toFixed(2));
      //   return Promise.resolve(grade)
      // }).catch(err => {
      //   this.domConsole.err("Erro inesperado durante o cálculo da nota.");// try and show error messages through domconsole
      //   this.domConsole.err(err.message);
      //   return Promise.resolve(0);
      // });
    } catch (error) {
      this.showErrorMessage(DOMConsole.ERR, StringTypes.MESSAGE, "unexpected_execution_error");
      this.domConsole.err(error.message);
      return Promise.resolve(0);
    } finally {
      Config.setConfig(this.old_config);
    }
  }

  showErrorMessage (errorID, ...args) {
    this.domConsole.err(LocalizedStrings.getError(errorID, args));
  }

  showInfoMessage (msgID, ...args) {
    this.domConsole.info(LocalizedStrings.getMessage(msgID, args));
  }

  writeToConsole (channel, msgType, msgID, ...args) {
    let msg = LocalizedStrings.getString(msgID, msgType);
    msg = LocalizedStrings.processString(msg, args);
    this.domConsole.writeRawHTML(msg, channel);
  }
}

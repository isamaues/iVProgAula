
export function createNumberResult (expected, generated, grade) {
  return new OutputMatchResult(expected, generated, grade, "number");
}

export function createBoolResult (expected, generated, grade) {
  return new OutputMatchResult(expected, generated, grade, "bool");
}

export function createStringResult (expected, generated, grade) {
  return new OutputMatchResult(expected, generated, grade, "string");
}

export class OutputMatchResult {

  constructor (expected, generated, grade, type) {
    this.expected = expected;
    this.generated = generated;
    this.grade = grade;
    this.type = type;
  }
}
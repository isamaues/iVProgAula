export class Input {

  requestInput () {
    throw new Error("Must be implemented");
  }

  cancelPendingInputRequests () {
    throw new Error("Must be implemented");
  }
}
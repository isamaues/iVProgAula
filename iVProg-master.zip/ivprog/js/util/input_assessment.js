import { Input } from './../io/input';
import { LocalizedStrings } from '../services/localizedStringsService';

export class InputAssessment extends Input {

  constructor (input_list) {
    super();
    this.index = 0;
    this.input_list = input_list.map((val) => {
      return {"value": val, "read": false};
    });
  }

  requestInput () {
    const promise = new Promise( (resolve, reject) => {
      if(this.index < this.input_list.length) {
        const input = this.input_list[this.index];
        input.read = true;
        this.index += 1;
        resolve(input.value);
      } else {
        reject(new Error(LocalizedStrings.getError("exceeded_input_request")));
      }
    });
    return promise
  }

  isInputAvailable () {
    return this.index < this.input_list.length;
  }
}
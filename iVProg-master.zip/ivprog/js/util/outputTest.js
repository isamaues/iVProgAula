import { Output } from "./../io/output";

export class OutputTest extends Output {
  constructor () {
    super();
    this.list = [];
    this.currentLine = null;
  }

  write (text, newLine = false) {
    if (this.currentLine == null) {
      this.currentLine = this.list.push("") - 1;
    }

    this.list[this.currentLine] += text;
    if (newLine) {
      this.currentLine = null;
    }
  }

  sendOutput (text) {
    const output = "" + text;
    if (output.indexOf("\n") !== -1) {
      const outputList = output.split("\n");
      const last = outputList.pop();
      outputList.forEach((t) => {
        //t = t.replace(/\t/g, '&#x0020;&#x0020;');
        //t = t.replace(/\s/g, "&#x0020;");
        if (t.length == 0) this.currentLine = null;
        else this.write(t, true);
      });
      //last = last.replace(/\t/g, '&#x0020;&#x0020;');
      //last = last.replace(/\s/g, "&#x0020;");
      if (last.length != 0) this.write(last);
    } else {
      //output = output.replace(/\t/g, '&#x0020;&#x0020;');
      //output = output.replace(/\s/g, "&#x0020;");
      this.write(output);
    }
  }
}

interface ConfigInterface {
  [id: string]: unknown;
}

class ConfigObject implements ConfigInterface {
  public decimalPlaces: number;
  public intConvertRoundMode: number;
  public default_lang: string;
  public enable_type_casting: boolean;
  public idle_input_interval: number;
  public suspend_threshold: number;
  public max_instruction_count: number;
  public activity_programming_type: Map<string, string>;
  public activity_functions: Map<string, boolean>;
  public activity_datatypes: Map<string, boolean>;
  public activity_commands: Map<string, boolean>;
  public activity_filter: Map<string, boolean>;
  [id: string]: unknown;

  constructor () {
    this.decimalPlaces = 8;
    this.intConvertRoundMode = 2;
    this.default_lang = "pt";
    this.enable_type_casting = true;
    this.idle_input_interval = 5000;
    this.suspend_threshold = 1000;
    // this.max_instruction_count = 350250; - automated evaluation limit
    this.max_instruction_count = Number.MAX_SAFE_INTEGER;
    this.activity_programming_type = new Map<string, string>();
    this.activity_functions = new Map<string, boolean>();
    this.activity_datatypes = new Map<string, boolean>();
    this.activity_commands = new Map<string, boolean>();
    this.activity_filter = new Map<string, boolean>();
  }

  setConfig (opts: object): void {
    const otherConfig = opts as ConfigInterface;
    for (const key in otherConfig) {
      if (Object.prototype.hasOwnProperty.call(this, key)) {
        this[key] = otherConfig[key];
      }
    }
  }
}

const config = new ConfigObject();
export const Config = config;

type Left<T> = { tag: "left"; value: T };
type Right<T> = { tag: "right"; value: T };
export type Either<L, R> = Left<L> | Right<R>;

export function left<T> (value: T): Left<T> {
  return {tag: "left", value: value}
}

export function right<T> (value: T): Right<T> {
  return {tag: "right", value: value}
}

export function match<T, L, R> (input: Either<L, R>, left: (l: L) => T, right: (right: R) => T): T {
  switch(input.tag) {
    case "left":
      return left(input.value);
    case "right":
      return right(input.value);
  }
}

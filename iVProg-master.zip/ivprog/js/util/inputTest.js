import { Input } from './../io/input';
import { LocalizedStrings } from '../services/localizedStringsService';

export class InputTest extends Input {

  constructor (inputList) {
    super();
    this.index = 0;
    this.inputList = inputList;
  }

  requestInput () {
    const promise = new Promise( (resolve, reject) => {
      if(this.index < this.inputList.length) {      
        resolve(this.inputList[this.index]);
        this.index++;
      } else {
        reject(new Error(LocalizedStrings.getError("exceeded_input_request")));
      }
    });
    return promise
  }
}
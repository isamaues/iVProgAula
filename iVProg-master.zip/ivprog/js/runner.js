import { IVProgParser } from './ast/ivprogParser';
import { IVProgProcessor } from './processor/ivprogProcessor';
import {DOMConsole} from './io/domConsole';
import { SemanticAnalyser } from './processor/semantic/semanticAnalyser';
import { Location } from "./memory/location";

export function runner () {


// const lexer = new ivprogLexer(new InputStream(input));
// const stream = new CommonTokenStream(lexer);
// stream.fill();
// let i = 1;
// let token = null;
// while ((token = stream.LT(i)).type !== ivprogLexer.EOF && token.type !== ivprogLexer.WHITESPACE) {
//     console.log(`${token.type}-${token.text}`);
//     console.log('\n')
//     i++;
// }
// const anaSin = new IVProgParser(input, ivprogLexer);
const editor = new window.JsonEditor('#json-renderer', {});
const domConsole = new DOMConsole("#console", true);
domConsole.hide();
// proc.interpretAST().then( sto => {
//   console.log(sto.applyStore('a'));
// }).catch(e => console.log(e));
try {
  window.$('#btn').click( () => {
    const input = window.$('#input').val();
    const analiser = IVProgParser.createParser(input);
    try {
      analiser.fill();
      //console.debug(analiser.tokenStream)
      const data = analiser.parseTree();
      const semAna = new SemanticAnalyser(data);
      const proc = new IVProgProcessor(semAna.analyseTree());
      proc.registerInput(domConsole);
      domConsole.clear();
      proc.registerOutput(domConsole);
      proc.interpretAST().then(sto => {
        console.log(sto);
        editor.load(sto.store);
        console.log(Location.size());
      }).catch( e => {
        alert(e);
        console.log(e);
        console.log(Location.size());
      });
    } catch (error) {
      alert(error);
      console.log(error);
      console.log(Location.size());
    }

  });
} catch(a) {
  console.log(a);
}
}

import { IType } from "./itype";

export class Type implements IType {
  public value: string;
  public ord: number;

  constructor (value: string, ord: number) {
    this.value = value;
    this.ord = ord;
  }

  stringInfo (): object[] {
    return [{ type: this.value, dim: 0 }];
  }

  isCompatible (another: IType): boolean {
    return this.value === another.value && this.ord === another.ord;
  }
}

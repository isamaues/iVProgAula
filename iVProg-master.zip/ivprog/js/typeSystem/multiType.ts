import { Type } from "./type";
import { IType } from "./itype";

export class MultiType implements IType {

  constructor (public types: Type[]) {
  }

  get value (): undefined {
    return undefined;
  }

  get ord (): undefined {
    return undefined;
  }

  stringInfo (): object[] {
    let list: object[] = [];
    for (let i = 0; i < this.types.length; i++) {
      const t = this.types[i];
      list = list.concat(t.stringInfo());
    }
    return list;
  }

  isCompatible (another: Type): boolean {
    for (let i = 0; i < this.types.length; i++) {
      const t = this.types[i];
      if (another.isCompatible(t)) {
        return true;
      }
    }
    return false;
  }
}

import { IType } from "./itype";
import { Type } from "./type";

export class ArrayType implements IType {

  public innerType: IType;

  constructor (type: Type, public dimensions: number) {
    this.innerType = type;
  }

  get isVector (): boolean {
    return this.dimensions == 1;
  }

  isCompatible (another: IType): boolean {
    if(another instanceof ArrayType){
      if(this.dimensions !== another.dimensions) {
        return false;
      }
      return this.innerType.isCompatible(another.innerType);
    }
    return false;
  }

  stringInfo (): object[] {
    const list = this.innerType.stringInfo();
    list.forEach(v => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const tmp = v as any;
      tmp.dim = this.dimensions;
    });
    return list;
  }

  get value (): undefined {
    return undefined;
  }

  get ord (): undefined {
    return undefined;
  }

  canAccept (another: IType, used_dims: number): boolean {
    const free_dims = this.dimensions - used_dims;
    if(another instanceof ArrayType) {
      return free_dims == another.dimensions && this.innerType.isCompatible(another.innerType);
    } else {
      return free_dims == 0 && this.innerType.isCompatible(another);
    }
  }
}

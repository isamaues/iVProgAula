import { Type } from "./type";
import { MultiType } from "./multiType";
import { IType } from "./itype";
import { Maybe } from "../util/maybe";

const INTEGER = new Type("integer", 0);
const REAL = new Type("real", 1);
const STRING = new Type("text", 2);
const BOOLEAN = new Type("boolean", 3);
const CHAR = new Type("char", 4);
const VOID = new Type("void", 5);
const UNDEFINED = new Type("undefined", 6);
const ALL = new MultiType([INTEGER, REAL, STRING, CHAR, BOOLEAN]);

interface TypeMap {
  [key: string]: IType;
}

export const Types = Object.freeze({
  INTEGER: INTEGER,
  REAL: REAL,
  STRING: STRING,
  CHAR: CHAR,
  BOOLEAN: BOOLEAN,
  VOID: VOID,
  UNDEFINED: UNDEFINED,
  ALL: ALL
});

export function fromOrdToType (ord: number): Maybe<IType> {
  const typeMap = Types as TypeMap;
  for (const t in typeMap) {
    if (typeMap[t].ord && typeMap[t].ord === ord){
      return Maybe.some<IType>(typeMap[t]);
    }
  }
  return Maybe.none<IType>();
}

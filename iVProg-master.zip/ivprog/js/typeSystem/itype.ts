// eslint-disable-next-line @typescript-eslint/interface-name-prefix
export interface IType {

  value: string | undefined;

  ord: number | undefined;

  stringInfo (): object[];

  isCompatible (another: IType): boolean;

}
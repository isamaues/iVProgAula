import { runner } from "./runner";
import {
  initVisualUI,
  addFunctionChangeListener,
  addGlobalChangeListener,
  removeFunctionListener,
  removeGlobalListener,
  getTestCases,
} from "./visualUI/functions";
import * as LocalizedStringsService from "./services/localizedStringsService";
import { i18nHelper } from "./services/i18nHelper";
import {
  ActionTypes,
  getLogs,
  getLogsAsString,
  registerClick,
  registerUserEvent,
  parseLogs,
} from "./services/userLog";
import {
  prepareActivityToStudentHelper,
  prepareActivityToStudentHelperJSON,
  autoEval,
  setPreviousAlgorithm
} from "./util/iassignHelpers";
import { openAssessmentDetail, levenshteinDistance } from "./util/utils";
import { Config } from "./util/config";
import { processData } from "./util/dataProcess";
import { parseExpression, parseCode } from "./util/parseFromVisual";
import * as CodeEditorAll from "./visualUI/text_editor";
import { autoGenerateTestCaseOutput } from "./util/auto_gen_output";
import { generate } from "./visualUI/code_generator";

const CodeEditor = {
  initTextEditor: CodeEditorAll.initTextEditor,
  setCode: CodeEditorAll.setCode,
  getCode: CodeEditorAll.getCode,
  updateEditor: CodeEditorAll.updateEditor,
  disable: CodeEditorAll.disable,
};

const Settings = {
  programming: [],
  functions: [],
  datatypes: [],
  commands: [],
  filter: []
}

const i18n = i18nHelper.i18n;
const LocalizedStrings = LocalizedStringsService.getInstance();

export {
  runner,
  initVisualUI,
  addFunctionChangeListener,
  addGlobalChangeListener,
  removeFunctionListener,
  removeGlobalListener,
  getTestCases,
  autoEval,
  prepareActivityToStudentHelper,
  prepareActivityToStudentHelperJSON,
  LocalizedStrings,
  i18n,
  getLogs,
  getLogsAsString,
  registerClick,
  registerUserEvent,
  parseLogs,
  ActionTypes,
  CodeEditor,
  openAssessmentDetail,
  autoGenerateTestCaseOutput,
  Config,
  parseExpression,
  parseCode,
  generate as generateCode,
  levenshteinDistance,
  processData,
  Settings,
  setPreviousAlgorithm
};

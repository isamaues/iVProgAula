const Readable = require("stream").Readable;
const csv = require("csv-parser");

function createStream (text) {
  const stream = new Readable();
  stream.push(text);
  stream.push(null);
  return stream;
}

module.exports = function (csv_data) {
  const callback = this.async();
  let csv_headers = [];
  const file_data = []
  const stream = createStream(csv_data);
  stream.pipe(csv())
  .on('error', error => callback(error))
  .on('headers', headers => csv_headers = headers)
  .on('data', data => file_data.push(data))
  .on('end', () => {
    const id = csv_headers[0];
    const messages = {};
    for(let i = 1; i < csv_headers.length; i += 1) {
      const lang = csv_headers[i];
      const strings = {};
      file_data.forEach( data => {
        strings[data[id]] = data[lang];
      });
      messages[lang] = strings;
    }
    callback(null, `module.exports = ${JSON.stringify(messages)}`);
  })
}


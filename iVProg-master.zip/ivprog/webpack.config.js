const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const UpdateVersionPlugin = require("./updateVersionPlugin");
//const ChangeScriptSourcePlugin = require('./changeScriptSourcePlugin');
const CopyPlugin = require("copy-webpack-plugin");
const CleanWebpackPlugin = require("clean-webpack-plugin").CleanWebpackPlugin;

module.exports = {
  entry: path.resolve(__dirname, "js/main.js"),
  output: {
    path: path.resolve(__dirname, "build", "js"),
    filename: "[name].[contenthash].js",
    library: "ivprogCore",
    libraryTarget: "umd",
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /(node_modules)/,
        use: {
          loader: "babel-loader",
          options: {
            presets: ["@babel/preset-env"],
          },
        },
      },
      {
        test: /\.tsx?$/,
        use: "ts-loader",
        exclude: /node_modules/,
      },
      {
        test: /\.csv$/,
        use: [
          {
            loader: path.resolve(__dirname, "i18n_csv_loader"),
          },
        ],
        exclude: /node_modules/,
      },
    ],
  },
  resolve: {
    extensions: [".tsx", ".ts", ".js", ".csv"],
    fallback: {
      fs: false,
    },
  },
  stats: {
    colors: true,
  },
  plugins: [
    new CleanWebpackPlugin({
      cleanOnceBeforeBuildPatterns: [path.resolve(__dirname, "build/**/*")],
      watch: true,
    }),
    new UpdateVersionPlugin(),
    new HtmlWebpackPlugin({
      template: "./templates/index.html",
      filename: path.resolve(__dirname, "build", "index.html"),
    }),
    new HtmlWebpackPlugin({
      template: "./templates/runner.html",
      filename: path.resolve(__dirname, "build", "runner.html"),
    }),
    new HtmlWebpackPlugin({
      template: "./templates/process.html",
      filename: path.resolve(__dirname, "build", "process.html"),
    }),
    /*new ChangeScriptSourcePlugin(),*/
    new CopyPlugin({
      patterns: [
        {
          from: "js/iassign-integration-functions.js",
          to: path.resolve(__dirname, "build/js"),
        },
        {
          from: "css/ivprog-visual-1.0.css",
          to: path.resolve(__dirname, "build/css"),
        },
        {
          from: "css/ivprog-term.css",
          to: path.resolve(__dirname, "build/css"),
        },
        {
          from: "css/ivprog-assessment.css",
          to: path.resolve(__dirname, "build/css"),
        },
        {
          from: "css/ivprog-editor.css",
          to: path.resolve(__dirname, "build/css"),
        },
        { from: "css/roboto.css", to: path.resolve(__dirname, "build/css") },
        { from: "css/fonts/", to: path.resolve(__dirname, "build/css/fonts") },
        { from: "js/Sortable.js", to: path.resolve(__dirname, "build/js") },
        { from: "js/jquery.min.js", to: path.resolve(__dirname, "build/js") },
        {
          from: "js/jquery-ui.min.js",
          to: path.resolve(__dirname, "build/js"),
        },
        { from: "js/semantic.min.js", to: path.resolve(__dirname, "build/js") },
        {
          from: "js/filesaver.min.js",
          to: path.resolve(__dirname, "build/js"),
        },
        {
          from: "css/semantic.min.css",
          to: path.resolve(__dirname, "build/css"),
        },
        {
          from: "css/themes/",
          to: path.resolve(__dirname, "build/css/themes"),
        },
        {
          from: "img/trash-icon.png",
          to: path.resolve(__dirname, "build/img"),
        },
        { from: "img/empty.svg", to: path.resolve(__dirname, "build/img") },
        { from: "img/new_line.svg", to: path.resolve(__dirname, "build/img") },
        {
          from: "img/no_new_line.svg",
          to: path.resolve(__dirname, "build/img"),
        },
        {
          from: "js/jquery.json-editor.min.js",
          to: path.resolve(__dirname, "build/js"),
        },
        {
          from: "node_modules/codemirror/lib/codemirror.css",
          to: path.resolve(__dirname, "build/css"),
        },
        {
          from: "node_modules/codemirror/addon/hint/show-hint.css",
          to: path.resolve(__dirname, "build/css"),
        },
        {
          from: "node_modules/codemirror/theme/ttcn.css",
          to: path.resolve(__dirname, "build/css"),
        },
        /*{from:'index.html', to:path.resolve(__dirname, 'build')},
        {from:'runner.html', to:path.resolve(__dirname, 'build')},*/
      ],
    }),
  ],
  optimization: {
    splitChunks: {
      chunks: "all",
    },
  },
  devtool: "source-map",
  watchOptions: {
    ignored: [path.resolve(__dirname, ".ima_version.json")],
  },
};

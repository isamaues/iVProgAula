declare module "*.csv" {
  const content: {[id: string]: unknown};
  export default content;
}

